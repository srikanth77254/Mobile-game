package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.AppDatabase
import com.example.data.ScoreRepository
import com.example.ui.components.GuideView
import com.example.ui.components.LeaderboardView
import com.example.ui.components.PongGame
import com.example.ui.components.SnakeGame
import com.example.ui.components.SpaceGame
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.WorkshopViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                // Initialize database & repository locally
                val context = LocalContext.current
                val database = remember { AppDatabase.getDatabase(context) }
                val repository = remember { ScoreRepository(database.scoreDao()) }
                
                // Retrieve ViewModel using Factory
                val workshopViewModel: WorkshopViewModel = viewModel(
                    factory = WorkshopViewModel.Factory(repository)
                )

                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF070B19) // Matching Space Deep Dark background
                ) {
                    MainScreen(viewModel = workshopViewModel)
                }
            }
        }
    }
}

@Composable
fun MainScreen(viewModel: WorkshopViewModel) {
    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
    val activeGameMode by viewModel.activeGameMode.collectAsStateWithLifecycle()

    // Observe high scores
    val spaceScores by viewModel.spaceEscapeScores.collectAsStateWithLifecycle()
    val snakeScores by viewModel.snakeScores.collectAsStateWithLifecycle()
    val pongScores by viewModel.pongScores.collectAsStateWithLifecycle()

    val currentHighScore = remember(activeGameMode, spaceScores, snakeScores, pongScores) {
        val scoresList = when (activeGameMode) {
            "SPACE_ESCAPE" -> spaceScores
            "SNAKE" -> snakeScores
            else -> pongScores
        }
        scoresList.firstOrNull()?.score ?: 0
    }

    // New High Score Dialog States
    var showSaveDialog by remember { mutableStateOf(false) }
    var scoreToSave by remember { mutableIntStateOf(0) }
    var gameModeToSave by remember { mutableStateOf("") }
    var pilotNameInput by remember { mutableStateOf("") }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            // Neon glassmorphic bottom navigation respecting system bar safe insets
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding(),
                color = Color(0xFF0C1227),
                tonalElevation = 8.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(BorderStroke(0.5.dp, Color(0x1F00E5FF)))
                        .padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    NavigationItem(
                        icon = Icons.Default.Gamepad,
                        label = "PLAY ZONE",
                        isSelected = selectedTab == 0,
                        onClick = { viewModel.selectTab(0) }
                    )
                    NavigationItem(
                        icon = Icons.Default.MenuBook,
                        label = "WORKBOOK",
                        isSelected = selectedTab == 1,
                        onClick = { viewModel.selectTab(1) }
                    )
                    NavigationItem(
                        icon = Icons.Default.EmojiEvents,
                        label = "LEADERBOARD",
                        isSelected = selectedTab == 2,
                        onClick = { viewModel.selectTab(2) }
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                0 -> {
                    // Play Zone Screen with multiple selectable mini-games
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color(0xFF070B19))
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                    ) {
                        // Game Selector Header Row
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0x1F1E294A))
                                .border(1.dp, Color(0x1F00E5FF), RoundedCornerShape(12.dp))
                                .padding(4.dp)
                        ) {
                            val games = listOf(
                                "SPACE_ESCAPE" to "SPACE ESCAPE",
                                "SNAKE" to "SNAKE",
                                "PONG" to "PONG"
                            )
                            games.forEach { (modeKey, label) ->
                                val isSelected = activeGameMode == modeKey
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isSelected) Color(0x3F00E5FF) else Color.Transparent)
                                        .clickable { viewModel.selectGameMode(modeKey) }
                                        .padding(vertical = 10.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = label,
                                        color = if (isSelected) Color(0xFF00E5FF) else Color.Gray,
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Render active game
                        Box(modifier = Modifier.weight(1f)) {
                            when (activeGameMode) {
                                "SPACE_ESCAPE" -> {
                                    SpaceGame(
                                        highScore = currentHighScore,
                                        onGameOver = { finalScore ->
                                            scoreToSave = finalScore
                                            gameModeToSave = "SPACE_ESCAPE"
                                            pilotNameInput = ""
                                            showSaveDialog = true
                                        }
                                    )
                                }
                                "SNAKE" -> {
                                    SnakeGame(
                                        highScore = currentHighScore,
                                        onGameOver = { finalScore ->
                                            scoreToSave = finalScore
                                            gameModeToSave = "SNAKE"
                                            pilotNameInput = ""
                                            showSaveDialog = true
                                        }
                                    )
                                }
                                "PONG" -> {
                                    PongGame(
                                        highScore = currentHighScore,
                                        onGameOver = { finalScore ->
                                            scoreToSave = finalScore
                                            gameModeToSave = "PONG"
                                            pilotNameInput = ""
                                            showSaveDialog = true
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
                1 -> {
                    // Guide View Workbook tab
                    GuideView()
                }
                2 -> {
                    // Leaderboard View tab
                    val scoresList = when (activeGameMode) {
                        "SPACE_ESCAPE" -> spaceScores
                        "SNAKE" -> snakeScores
                        else -> pongScores
                    }
                    LeaderboardView(
                        activeGameMode = activeGameMode,
                        scores = scoresList,
                        onClearScores = { mode -> viewModel.clearAllScores(mode) },
                        onGameModeChange = { mode -> viewModel.selectGameMode(mode) }
                    )
                }
            }

            // Save Score Dialog
            if (showSaveDialog) {
                Dialog(onDismissRequest = { showSaveDialog = false }) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF0C1227)),
                        border = BorderStroke(1.5.dp, Color(0xFF00E5FF)),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                "NEW MISSION LOGGED",
                                color = Color(0xFF00E5FF),
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(bottom = 12.dp)
                            )

                            Text(
                                "Your Score: $scoreToSave",
                                color = Color.White,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.ExtraBold,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(bottom = 16.dp)
                            )

                            Text(
                                "Enter pilot callsign to save entry in high-scores leaderboard:",
                                color = Color.LightGray,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(bottom = 16.dp)
                            )

                            OutlinedTextField(
                                value = pilotNameInput,
                                onValueChange = { if (it.length <= 15) pilotNameInput = it },
                                placeholder = { Text("PILOT CALLSIGN", color = Color.Gray, fontSize = 12.sp) },
                                singleLine = true,
                                shape = RoundedCornerShape(8.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedBorderColor = Color(0xFF00E5FF),
                                    unfocusedBorderColor = Color(0x3F00E5FF),
                                    cursorColor = Color(0xFF00E5FF)
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(24.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                TextButton(onClick = { showSaveDialog = false }) {
                                    Text("SKIP", color = Color.Gray, fontWeight = FontWeight.Bold)
                                }

                                Button(
                                    onClick = {
                                        viewModel.saveScore(pilotNameInput, scoreToSave, gameModeToSave)
                                        showSaveDialog = false
                                        // Navigate to leaderboards immediately so they can see their entry
                                        viewModel.selectTab(2)
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFF00E5FF),
                                        contentColor = Color.Black
                                    ),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("REGISTER SCORE", fontWeight = FontWeight.ExtraBold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun NavigationItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val activeColor = Color(0xFF00E5FF)
    val inactiveColor = Color.Gray

    Column(
        modifier = Modifier
            .clickable { onClick() }
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (isSelected) activeColor else inactiveColor,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            color = if (isSelected) activeColor else inactiveColor,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}
