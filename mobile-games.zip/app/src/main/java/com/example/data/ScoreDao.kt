package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ScoreDao {
    @Query("SELECT * FROM scores WHERE gameMode = :gameMode ORDER BY score DESC, timestamp DESC LIMIT 10")
    fun getTopScores(gameMode: String): Flow<List<ScoreEntry>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScore(score: ScoreEntry)

    @Query("DELETE FROM scores WHERE gameMode = :gameMode")
    suspend fun clearScores(gameMode: String)
}
