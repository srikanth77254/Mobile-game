package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "scores")
data class ScoreEntry(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val playerName: String,
    val score: Int,
    val gameMode: String, // "SPACE_ESCAPE", "SNAKE", "PONG"
    val timestamp: Long = System.currentTimeMillis()
)
