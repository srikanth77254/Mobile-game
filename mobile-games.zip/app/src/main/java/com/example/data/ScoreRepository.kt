package com.example.data

import kotlinx.coroutines.flow.Flow

class ScoreRepository(private val scoreDao: ScoreDao) {
    fun getTopScores(gameMode: String): Flow<List<ScoreEntry>> {
        return scoreDao.getTopScores(gameMode)
    }

    suspend fun insertScore(score: ScoreEntry) {
        scoreDao.insertScore(score)
    }

    suspend fun clearScores(gameMode: String) {
        scoreDao.clearScores(gameMode)
    }
}
