package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive

/**
 * BaseGameEngine: A highly reusable, type-safe boiler-plate game component
 * designed specifically for workshops and rapid game prototyping in Jetpack Compose.
 *
 * It abstracts:
 * 1. High-Performance 60FPS Game Loop utilizing Coroutines.
 * 2. High-Fidelity Canvas setup with custom dimensions and safe insets.
 * 3. Reactive HUD showing Title, current Score, and persistent High-Score.
 * 4. Structured Game State machine: READY (Start Screen), PLAYING, PAUSED, GAME_OVER.
 * 5. Flexible drag/touch input gestures mapped to coordinates.
 */

enum class GameStatus { READY, PLAYING, PAUSED, GAME_OVER }

@Composable
fun <T> BaseGameEngine(
    gameTitle: String,
    themeColor: Color,
    initialGameState: () -> T,
    highScore: Int,
    onGameOver: (Int) -> Unit,
    onGameTick: (T) -> Pair<T, Boolean>, // Returns next state and whether game is over
    onDragInput: (T, Offset) -> T, // Map drag gestures directly to state mutations
    drawGame: DrawScope.(state: T) -> Unit, // Declarative drawing function
    modifier: Modifier = Modifier,
    gameInstructions: String = "Drag screen to interact. Achieve the highest score!",
    onStartGame: () -> Unit = {}
) {
    // --- State Management ---
    var gameStatus by remember { mutableStateOf(GameStatus.READY) }
    var score by remember { mutableStateOf(0) }
    var gameState by remember { mutableStateOf(initialGameState()) }
    
    // Track score ticks (increases every second the player survives, or customized)
    var gameLoopCount by remember { mutableStateOf(0L) }

    // --- Main Game Loop (LaunchedEffect driven at ~60fps) ---
    LaunchedEffect(gameStatus) {
        if (gameStatus != GameStatus.PLAYING) return@LaunchedEffect
        
        while (isActive) {
            delay(16) // ~60 FPS
            gameLoopCount++

            // Tick game state
            val (nextState, isFinished) = onGameTick(gameState)
            gameState = nextState

            // Auto-increment score slowly over survival time
            if (gameLoopCount % 60L == 0L) {
                score += 5
            }

            if (isFinished) {
                gameStatus = GameStatus.GAME_OVER
                onGameOver(score)
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(16.dp))
            .border(2.dp, themeColor.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
            .background(Color(0xFF070B19))
    ) {
        // Space/Cosmic ambient backgrounds
        StarrySky(speedFactor = if (gameStatus == GameStatus.PLAYING) 1.5f else 0.4f)

        // --- Core Interactivity Canvas & Gesture Interceptor ---
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(gameStatus) {
                    if (gameStatus != GameStatus.PLAYING) return@pointerInput
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        gameState = onDragInput(gameState, dragAmount)
                    }
                }
        ) {
            drawGame(gameState)
        }

        // --- HUD Overlay (Heads-Up Display) ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Live Score Board
            Column(
                modifier = Modifier
                    .background(Color(0x7F0A0E1A), RoundedCornerShape(8.dp))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "SCORE",
                    color = Color(0xFFA0AEC0),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = String.format("%04d", score),
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Monospace
                )
            }

            // Centralized Game Banner
            Text(
                text = gameTitle.uppercase(),
                color = themeColor,
                fontSize = 13.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace
            )

            // Dynamic High Score Board
            Column(
                modifier = Modifier
                    .background(Color(0x7F0A0E1A), RoundedCornerShape(8.dp))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalAlignment = Alignment.End
            ) {
                Text(
                    text = "HI-SCORE",
                    color = Color(0xFFA0AEC0),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = String.format("%04d", maxOf(highScore, score)),
                    color = Color(0xFFFFD700),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        // Pause Game Button (Only visible during play)
        if (gameStatus == GameStatus.PLAYING) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(top = 80.dp, end = 16.dp),
                contentAlignment = Alignment.TopEnd
            ) {
                IconButton(
                    onClick = { gameStatus = GameStatus.PAUSED },
                    modifier = Modifier
                        .size(36.dp)
                        .background(Color(0x7F0A0E1A), RoundedCornerShape(18.dp))
                ) {
                    Icon(
                        Icons.Filled.Pause,
                        contentDescription = "Pause",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        // --- OVERLAYS: Ready / Paused / Game Over ---
        when (gameStatus) {
            GameStatus.READY -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xEE070B19)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(24.dp)
                    ) {
                        Text(
                            text = gameTitle,
                            color = themeColor,
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "WORKSHOP BOILERPLATE ENGINE",
                            color = Color.Gray,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(top = 4.dp, bottom = 24.dp)
                        )

                        Text(
                            text = gameInstructions,
                            color = Color.White.copy(alpha = 0.8f),
                            fontSize = 13.sp,
                            modifier = Modifier.padding(bottom = 32.dp)
                        )

                        Button(
                            onClick = {
                                gameState = initialGameState()
                                score = 0
                                gameLoopCount = 0
                                gameStatus = GameStatus.PLAYING
                                onStartGame()
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = themeColor,
                                contentColor = Color.Black
                            ),
                            shape = RoundedCornerShape(32.dp),
                            modifier = Modifier
                                .width(220.dp)
                                .height(56.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.PlayArrow, contentDescription = "Start")
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("LAUNCH MISSION", fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
                            }
                        }
                    }
                }
            }

            GameStatus.PAUSED -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xCC070B19)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "MISSION PAUSED",
                            color = Color.White,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(bottom = 24.dp)
                        )

                        Button(
                            onClick = { gameStatus = GameStatus.PLAYING },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = themeColor,
                                contentColor = Color.Black
                            )
                        ) {
                            Text("RESUME", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            GameStatus.GAME_OVER -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xEE070B19)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "MISSION FAILED",
                            color = Color(0xFFFF5252),
                            fontSize = 26.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Final Score: $score",
                            color = Color.White,
                            fontSize = 16.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(top = 8.dp, bottom = 24.dp)
                        )

                        Button(
                            onClick = {
                                gameState = initialGameState()
                                score = 0
                                gameLoopCount = 0
                                gameStatus = GameStatus.PLAYING
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = themeColor,
                                contentColor = Color.Black
                            )
                        ) {
                            Text("RETRY MISSION", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            GameStatus.PLAYING -> {
                // No overlay displayed during active play
            }
        }
    }
}
