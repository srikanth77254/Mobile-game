package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class GuideItem(
    val title: String,
    val subtitle: String,
    val content: String,
    val note: String = ""
)

data class PromptPhase(
    val name: String,
    val tag: String,
    val prompts: List<GuideItem>
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GuideView(
    modifier: Modifier = Modifier
) {
    val clipboardManager = LocalClipboardManager.current
    var activeMainTab by remember { mutableStateOf(0) } // 0: Step-by-Step, 1: Prompt Guide

    // --- Interactive Checklists ---
    var checkedPre1 by remember { mutableStateOf(false) }
    var checkedPre2 by remember { mutableStateOf(false) }
    var checkedPre3 by remember { mutableStateOf(false) }
    var checkedPre4 by remember { mutableStateOf(false) }
    var checkedPre5 by remember { mutableStateOf(false) }

    // --- Prompt Guide Data ---
    val promptPhases = remember {
        listOf(
            PromptPhase(
                name = "Phase 1: Setup",
                tag = "P1",
                prompts = listOf(
                    GuideItem(
                        title = "Prompt 1a — Create the project",
                        subtitle = "Bootstrapping structural framework",
                        content = "I am a complete beginner in React Native and Expo.\nHelp me create a new Expo project called SpaceEscapeRunner.\nGive me:\n1. Installation prerequisites\n2. Commands to create the project\n3. Commands to run the project\n4. Explain what each command does\n5. How to test the app using Expo Go\nDo not generate game code yet.",
                        note = "Pro tip: In Android, this initial bootstrap is done via the Android Studio New Project Wizard selecting Jetpack Compose Template!"
                    ),
                    GuideItem(
                        title = "Prompt 1b — First game screen",
                        subtitle = "Drafting welcome dashboard",
                        content = "The Expo project is running successfully.\nGenerate a simple game screen with:\n- Title: Space Escape Runner\n- Current Score\n- Start Game Button\nUse a clean modern UI.\nExplain every line of code for a beginner."
                    )
                )
            ),
            PromptPhase(
                name = "Phase 2: Spaceship",
                tag = "P2",
                prompts = listOf(
                    GuideItem(
                        title = "Prompt 2a — Add the spaceship",
                        subtitle = "Rendering customized player geometry",
                        content = "Now add a spaceship at the bottom of the screen.\nRequirements:\n- Use React Native Views only.\n- Do not use images.\n- Represent the spaceship using shapes and colors.\n- Position it at the bottom center.\nExplain all styling and positioning logic.",
                        note = "In Compose, we use the custom Canvas block or custom Vector draws to render high-fidelity shapes with stellar efficiency!"
                    ),
                    GuideItem(
                        title = "Prompt 2b — Left / right controls",
                        subtitle = "Adding player input",
                        content = "Add left and right movement controls.\nRequirements:\n- Add two buttons: Move Left and Move Right.\n- Spaceship should move horizontally.\n- Prevent moving outside screen boundaries.\nExplain state management step by step."
                    )
                )
            ),
            PromptPhase(
                name = "Phase 3: Game Loop",
                tag = "P3",
                prompts = listOf(
                    GuideItem(
                        title = "Prompt 3a — Falling asteroids",
                        subtitle = "Driving continuous linear physics",
                        content = "Add falling asteroids.\nRequirements:\n- Generate asteroid at a random x position.\n- Asteroid falls continuously from the top.\n- When asteroid reaches the bottom:\n    - Create a new asteroid.\n    - Increase the score.\nKeep the implementation beginner friendly.\nExplain the game loop logic.",
                        note = "We drive this using a Coroutine loop with delay(16) in our LaunchedEffect to target smooth 60fps."
                    ),
                    GuideItem(
                        title = "Prompt 3b — Collision detection",
                        subtitle = "Computing geometrical interception",
                        content = "Add collision detection.\nRequirements:\n- Detect collision between asteroid and spaceship.\n- Show a Game Over message.\n- Stop the game loop.\n- Show the final score.\nExplain the collision calculation step by step."
                    )
                )
            ),
            PromptPhase(
                name = "Phase 4: Save & Reset",
                tag = "P4",
                prompts = listOf(
                    GuideItem(
                        title = "Prompt 4a — Restart functionality",
                        subtitle = "Resetting atomic state bindings",
                        content = "Add Restart Game functionality.\nRequirements:\n- Reset score\n- Reset asteroid position\n- Reset spaceship position\n- Start the game again\nExplain how state reset works."
                    ),
                    GuideItem(
                        title = "Prompt 4b — High score with AsyncStorage",
                        subtitle = "Preserving achievements locally",
                        content = "Add local high score storage using AsyncStorage.\nRequirements:\n- Save the highest score\n- Load the high score when the app starts\n- Display the high score on screen\nExplain AsyncStorage in simple terms.",
                        note = "For pure Android performance, we integrate local Room Database SQLite persistence instead of AsyncStorage!"
                    )
                )
            ),
            PromptPhase(
                name = "Phase 5: Visual Polish",
                tag = "P5",
                prompts = listOf(
                    GuideItem(
                        title = "Prompt 5 — Visual polish",
                        subtitle = "Elevating visuals",
                        content = "Improve the UI. Add:\n- Gradient background\n- Better spaceship design\n- Better asteroid design\n- Smooth animations\n- Modern game UI\nKeep the code simple and Expo compatible.",
                        note = "Our Space Escape Runner features stunning glassmorphic neon widgets, vector rocket fire, and animated space particles!"
                    )
                )
            ),
            PromptPhase(
                name = "Phase 6: Cloud Build",
                tag = "P6",
                prompts = listOf(
                    GuideItem(
                        title = "Prompt 6 — Generate the Android build",
                        subtitle = "EAS Cloud packaging instructions",
                        content = "The game is complete. Guide me step by step to:\n1. Create an Expo account\n2. Configure EAS\n3. Generate an Android APK\n4. Generate an Android AAB\n5. Download the build\nExplain each command and the expected output."
                    )
                )
            ),
            PromptPhase(
                name = "Phase 7: Publish",
                tag = "P7",
                prompts = listOf(
                    GuideItem(
                        title = "Prompt 7 — Full Play Console walkthrough",
                        subtitle = "Navigating Store listings & compliance",
                        content = "The Android AAB build is ready. Guide me step by step to publish\nSpace Escape Runner on the Google Play Console using a developer\naccount. Explain the complete process, including:\n1. Developer Account Setup\n2. Store listings entries\n3. Screenshots, dimensions\n4. Closed testing tracks requirements\n5. Signatures and compliance forms."
                    )
                )
            )
        )
    }

    var selectedPhaseIndex by remember { mutableStateOf(0) }
    var copiedPromptId by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF070B19))
    ) {
        // --- Header Section ---
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color(0xFF0E162D), Color(0xFF070B19))
                    )
                )
                .padding(horizontal = 20.dp, vertical = 16.dp)
        ) {
            Column {
                Text(
                    text = "VIBE-CODING GUIDE",
                    color = Color(0xFF00E5FF),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Companion Workbook for Build & Publish Live Session",
                    color = Color.White.copy(alpha = 0.7f),
                    fontSize = 12.sp,
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Custom Tab Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0x1F1E294A))
                        .padding(4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (activeMainTab == 0) Color(0x3F00E5FF) else Color.Transparent)
                            .clickable { activeMainTab = 0 }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "STEP-BY-STEP",
                            color = if (activeMainTab == 0) Color(0xFF00E5FF) else Color.Gray,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (activeMainTab == 1) Color(0x3F00E5FF) else Color.Transparent)
                            .clickable { activeMainTab = 1 }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "PROMPT GUIDE",
                            color = if (activeMainTab == 1) Color(0xFF00E5FF) else Color.Gray,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (activeMainTab == 2) Color(0x3F00E5FF) else Color.Transparent)
                            .clickable { activeMainTab = 2 }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "BOILERPLATE",
                            color = if (activeMainTab == 2) Color(0xFF00E5FF) else Color.Gray,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        // --- Body Content ---
        when (activeMainTab) {
            0 -> {
                // STEP BY STEP GUIDE
                LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                contentPadding = PaddingValues(bottom = 32.dp)
            ) {
                // Intro card
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0x131E294A)),
                        border = BorderStroke(1.dp, Color(0x1F00E5FF)),
                        modifier = Modifier.padding(top = 8.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                "Hands-On Workshop Guide",
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                "This guide helps you understand the entire AI-driven development pipeline. Play the pre-built game on the Play zone, or use the copied prompts in your favorite AI workspace to build your own from scratch!",
                                color = Color.White.copy(alpha = 0.7f),
                                fontSize = 12.sp,
                                lineHeight = 18.sp
                            )
                        }
                    }
                }

                // Tech Stack Summary
                item {
                    Text(
                        "THE WORKSHOP TECH STACK",
                        color = Color(0xFFFF007F),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(start = 4.dp, top = 8.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .background(Color(0x0AFFFFFF), RoundedCornerShape(12.dp))
                                .border(1.dp, Color(0x16FFFFFF), RoundedCornerShape(12.dp))
                                .padding(12.dp)
                        ) {
                            Icon(Icons.Filled.Build, contentDescription = null, tint = Color(0xFF00E5FF), modifier = Modifier.size(24.dp))
                            Text("Expo / RN", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                            Text("Fast prototyping & instant on-device hot reload.", color = Color.Gray, fontSize = 10.sp, lineHeight = 14.sp)
                        }
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .background(Color(0x0AFFFFFF), RoundedCornerShape(12.dp))
                                .border(1.dp, Color(0x16FFFFFF), RoundedCornerShape(12.dp))
                                .padding(12.dp)
                        ) {
                            Icon(Icons.Filled.Code, contentDescription = null, tint = Color(0xFFFF007F), modifier = Modifier.size(24.dp))
                            Text("AI Assistants", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                            Text("Cursor / Claude AI driving code writing incrementally.", color = Color.Gray, fontSize = 10.sp, lineHeight = 14.sp)
                        }
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .background(Color(0x0AFFFFFF), RoundedCornerShape(12.dp))
                                .border(1.dp, Color(0x16FFFFFF), RoundedCornerShape(12.dp))
                                .padding(12.dp)
                        ) {
                            Icon(Icons.Filled.CloudUpload, contentDescription = null, tint = Color(0xFF8A2BE2), modifier = Modifier.size(24.dp))
                            Text("EAS Cloud", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                            Text("Cloud builds for production .aab packages.", color = Color.Gray, fontSize = 10.sp, lineHeight = 14.sp)
                        }
                    }
                }

                // Pre-requisites list
                item {
                    Text(
                        "BEFORE YOU START CHECKLIST",
                        color = Color(0xFF00E5FF),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(start = 4.dp, top = 8.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0x0AFFFFFF), RoundedCornerShape(12.dp))
                            .border(1.dp, Color(0x16FFFFFF), RoundedCornerShape(12.dp))
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        CheckableRow(label = "Node.js (LTS version) installed locally", checked = checkedPre1, onCheckedChange = { checkedPre1 = it })
                        CheckableRow(label = "A code editor (Cursor or VS Code with Claude extension)", checked = checkedPre2, onCheckedChange = { checkedPre2 = it })
                        CheckableRow(label = "The Expo Go app installed on your Android test phone", checked = checkedPre3, onCheckedChange = { checkedPre3 = it })
                        CheckableRow(label = "A free Expo (EAS) account created in advance", checked = checkedPre4, onCheckedChange = { checkedPre4 = it })
                        CheckableRow(label = "A Google Play Developer Account (optional)", checked = checkedPre5, onCheckedChange = { checkedPre5 = it })
                    }
                }

                // Core Working Loop
                item {
                    Text(
                        "THE CORE VIBE-CODING WORKFLOW",
                        color = Color(0xFFFF007F),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(start = 4.dp, top = 8.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0x0AFFFFFF), RoundedCornerShape(12.dp))
                            .border(1.dp, Color(0x16FFFFFF), RoundedCornerShape(12.dp))
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        WorkflowStep(num = "1", title = "Prompt AI", desc = "Input prompt for the current phase from the Prompt Guide tab.")
                        WorkflowStep(num = "2", title = "Review & Learn", desc = "Read AI's code design explanation to grasp state/layout mechanics.")
                        WorkflowStep(num = "3", title = "Apply & Test", desc = "Save changes and verify instantly on your phone via Expo Go.")
                        WorkflowStep(num = "4", title = "Iterate", desc = "Confirm success before proceeding. If bugs pop up, prompt the error back!")
                    }
                }
            }
            }
            1 -> {
                // PROMPT GUIDE
                Column(modifier = Modifier.fillMaxSize()) {
                // Phase Tab Row
                ScrollableTabRow(
                    selectedTabIndex = selectedPhaseIndex,
                    containerColor = Color(0xFF0C1227),
                    contentColor = Color(0xFF00E5FF),
                    edgePadding = 16.dp,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[selectedPhaseIndex]),
                            color = Color(0xFF00E5FF)
                        )
                    }
                ) {
                    promptPhases.forEachIndexed { index, phase ->
                        Tab(
                            selected = selectedPhaseIndex == index,
                            onClick = { selectedPhaseIndex = index },
                            text = {
                                Text(
                                    phase.tag,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 12.sp
                                )
                            }
                        )
                    }
                }

                // Active Phase Title & Description
                val activePhase = promptPhases[selectedPhaseIndex]
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp)
                ) {
                    item {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                activePhase.name.uppercase(),
                                color = Color(0xFF00E5FF),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                "STEPS: ${activePhase.prompts.size}",
                                color = Color.Gray,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    items(activePhase.prompts) { item ->
                        var isExpanded by remember { mutableStateOf(true) }

                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0x1F1E294A)),
                            border = BorderStroke(1.dp, Color(0x3F00E5FF)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { isExpanded = !isExpanded },
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            item.title,
                                            color = Color.White,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            item.subtitle,
                                            color = Color(0xFFFF007F),
                                            fontSize = 11.sp,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                    Icon(
                                        imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                        contentDescription = "Toggle",
                                        tint = Color.Gray
                                    )
                                }

                                AnimatedVisibility(
                                    visible = isExpanded,
                                    enter = expandVertically(),
                                    exit = shrinkVertically()
                                ) {
                                    Column {
                                        Spacer(modifier = Modifier.height(12.dp))

                                        // Copied Indicator
                                        val isCopied = copiedPromptId == "${selectedPhaseIndex}_${item.title}"

                                        // Code Prompt Box
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(Color(0xFF070B19))
                                                .border(1.dp, Color(0x3F00E5FF), RoundedCornerShape(8.dp))
                                                .padding(12.dp)
                                        ) {
                                            Text(
                                                text = item.content,
                                                color = Color(0xFF00E5FF),
                                                fontSize = 11.sp,
                                                fontFamily = FontFamily.Monospace,
                                                lineHeight = 16.sp
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(10.dp))

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            // Optional android note
                                            if (item.note.isNotEmpty()) {
                                                Text(
                                                    text = item.note,
                                                    color = Color.LightGray.copy(alpha = 0.5f),
                                                    fontSize = 9.sp,
                                                    lineHeight = 12.sp,
                                                    modifier = Modifier.weight(1f).padding(end = 8.dp)
                                                )
                                            } else {
                                                Spacer(modifier = Modifier.weight(1f))
                                            }

                                            Button(
                                                onClick = {
                                                    clipboardManager.setText(AnnotatedString(item.content))
                                                    copiedPromptId = "${selectedPhaseIndex}_${item.title}"
                                                },
                                                colors = ButtonDefaults.buttonColors(
                                                    containerColor = if (isCopied) Color(0xFF4CAF50) else Color(0xFF00E5FF),
                                                    contentColor = Color.Black
                                                ),
                                                shape = RoundedCornerShape(8.dp),
                                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                                modifier = Modifier.height(32.dp)
                                            ) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Icon(
                                                        imageVector = if (isCopied) Icons.Default.Check else Icons.Default.ContentCopy,
                                                        contentDescription = null,
                                                        modifier = Modifier.size(14.dp)
                                                    )
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text(
                                                        text = if (isCopied) "COPIED" else "COPY PROMPT",
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            }
            2 -> {
                BoilerplateSandboxView()
            }
        }
    }
}

data class BoilerplateState(
    val playerX: Float = 0.5f,
    val obstacleX: Float = 0.5f,
    val obstacleY: Float = 0.0f,
    val obstacleSpeed: Float = 0.012f
)

@Composable
fun BoilerplateSandboxView() {
    var highScore by remember { mutableStateOf(0) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0x131E294A)),
                border = BorderStroke(1.dp, Color(0x1F00E5FF)),
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "Unified Engine Sandbox",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        "Below is an interactive live demonstration built entirely with our BaseGameEngine boilerplate. It handles coroutine loops (~60 FPS), game states, and HUD overlays seamlessly.",
                        color = Color.White.copy(alpha = 0.7f),
                        fontSize = 12.sp,
                        lineHeight = 18.sp
                    )
                }
            }
        }

        // Live interactive game using BaseGameEngine
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp)
            ) {
                BaseGameEngine(
                    gameTitle = "Stardust Dodge",
                    themeColor = Color(0xFF00E5FF),
                    initialGameState = { BoilerplateState() },
                    highScore = highScore,
                    onGameOver = { finalScore ->
                        if (finalScore > highScore) {
                            highScore = finalScore
                        }
                    },
                    onGameTick = { state ->
                        val nextY = state.obstacleY + state.obstacleSpeed
                        val isCollision = kotlin.math.abs(state.playerX - state.obstacleX) < 0.12f && kotlin.math.abs(1.0f - nextY) < 0.1f
                        if (nextY >= 1.0f) {
                            Pair(
                                state.copy(
                                    obstacleX = kotlin.random.Random.nextFloat(),
                                    obstacleY = 0f,
                                    obstacleSpeed = (state.obstacleSpeed + 0.001f).coerceAtMost(0.035f)
                                ),
                                false
                            )
                        } else {
                            Pair(state.copy(obstacleY = nextY), isCollision)
                        }
                    },
                    onDragInput = { state, dragAmount ->
                        val nextX = (state.playerX + dragAmount.x / 1000f).coerceIn(0.05f, 0.95f)
                        state.copy(playerX = nextX)
                    },
                    drawGame = { state ->
                        val canvasWidth = size.width
                        val canvasHeight = size.height

                        // Draw falling asteroid obstacle
                        drawCircle(
                            color = Color(0xFFFFD700),
                            radius = 16.dp.toPx(),
                            center = Offset(state.obstacleX * canvasWidth, state.obstacleY * canvasHeight)
                        )

                        // Draw player sphere
                        drawCircle(
                            color = Color(0xFF00E5FF),
                            radius = 12.dp.toPx(),
                            center = Offset(state.playerX * canvasWidth, canvasHeight - 40.dp.toPx())
                        )
                    },
                    gameInstructions = "Slide left/right on screen to dodge the golden stardust!"
                )
            }
        }

        // Code and Explanation Card
        item {
            Text(
                "HOW THE BASE BOILERPLATE WORKS",
                color = Color(0xFFFF007F),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(start = 4.dp, top = 8.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0x0AFFFFFF), RoundedCornerShape(12.dp))
                    .border(1.dp, Color(0x16FFFFFF), RoundedCornerShape(12.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                BulletPoint(title = "60 FPS Game Loop", desc = "Uses standard LaunchedEffect and kotlinx.coroutines.delay to tick the game state at exactly ~16ms intervals.")
                BulletPoint(title = "Type-Safe State <T>", desc = "Accepts generic state parameters, letting you represent grids (Snake), vectors (Space), or vectors/coordinates (Pong) with zero friction.")
                BulletPoint(title = "Input Management", desc = "Exposes onDragInput to capture pointer actions natively without complex gesture detectors.")
                BulletPoint(title = "Centralized HUD", desc = "Includes high-score caching, current session scoring, and standard pause/game-over overlays automatically.")
            }
        }
    }
}

@Composable
fun BulletPoint(title: String, desc: String) {
    Row(modifier = Modifier.fillMaxWidth()) {
        Text("•", color = Color(0xFF00E5FF), fontWeight = FontWeight.Bold, modifier = Modifier.padding(end = 8.dp))
        Column {
            Text(title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text(desc, color = Color.Gray, fontSize = 11.sp, lineHeight = 15.sp)
        }
    }
}

@Composable
fun CheckableRow(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = if (checked) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
            contentDescription = null,
            tint = if (checked) Color(0xFF00E5FF) else Color.Gray,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(10.dp))
        Text(
            text = label,
            color = if (checked) Color.White else Color.LightGray,
            fontSize = 12.sp
        )
    }
}

@Composable
fun WorkflowStep(
    num: String,
    title: String,
    desc: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .size(24.dp)
                .clip(CircleShape)
                .background(Color(0xFF00E5FF)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = num,
                color = Color.Black,
                fontSize = 11.sp,
                fontWeight = FontWeight.ExtraBold,
                fontFamily = FontFamily.Monospace
            )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Text(
                text = title.uppercase(),
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Text(
                text = desc,
                color = Color.Gray,
                fontSize = 10.sp,
                lineHeight = 14.sp,
                modifier = Modifier.padding(top = 2.dp)
            )
        }
    }
}
