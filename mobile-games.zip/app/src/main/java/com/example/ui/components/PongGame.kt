package com.example.ui.components

import androidx.compose.animation.core.animateOffsetAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlin.random.Random

@Composable
fun PongGame(
    highScore: Int,
    onGameOver: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    // Relative game positions (0.0f to 1.0f)
    var ballX by remember { mutableStateOf(0.5f) }
    var ballY by remember { mutableStateOf(0.5f) }
    var ballVx by remember { mutableStateOf(0.008f) }
    var ballVy by remember { mutableStateOf(0.004f) }

    // Paddles (X centers, Y bounds)
    var playerY by remember { mutableStateOf(0.5f) } // Left paddle (controlled by player)
    var aiY by remember { mutableStateOf(0.5f) }     // Right paddle (AI tracked)

    val paddleHeight = 0.18f
    val paddleWidth = 0.03f
    val ballSize = 0.02f

    // States
    var score by remember { mutableStateOf(0) }
    var isPlaying by remember { mutableStateOf(false) }
    var isGameOver by remember { mutableStateOf(false) }

    // Game loop
    LaunchedEffect(isPlaying) {
        if (!isPlaying) return@LaunchedEffect
        while (isActive) {
            delay(16) // ~60 FPS

            // Move ball
            ballX += ballVx
            ballY += ballVy

            // Collide top and bottom walls
            if (ballY - ballSize < 0f) {
                ballY = ballSize
                ballVy = -ballVy
            } else if (ballY + ballSize > 1.0f) {
                ballY = 1.0f - ballSize
                ballVy = -ballVy
            }

            // AI paddle logic (moves towards ballY with delay/speed restriction to make it beatable)
            val aiSpeed = 0.0055f
            if (ballX > 0.4f) {
                val diff = ballY - aiY
                if (Math.abs(diff) > 0.02f) {
                    aiY += Math.signum(diff) * aiSpeed
                    aiY = aiY.coerceIn(paddleHeight / 2f, 1f - paddleHeight / 2f)
                }
            }

            // Paddle collisions
            // 1. Left Paddle (Player) at X = 0.05f
            if (ballX - ballSize < 0.05f + paddleWidth / 2f) {
                // Check if Y overlaps Player Paddle
                if (ballY >= playerY - paddleHeight / 2f && ballY <= playerY + paddleHeight / 2f) {
                    ballX = 0.05f + paddleWidth / 2f + ballSize
                    // Reverse X and slightly randomize / adjust Y speed depending on where it hits the paddle
                    val relativeHit = (ballY - playerY) / (paddleHeight / 2f)
                    ballVx = -ballVx * 1.05f // Speed up slightly!
                    ballVy = relativeHit * 0.01f
                    score += 1 // Increment points for successful block
                } else if (ballX < 0f) {
                    // Missed! Game Over
                    isPlaying = false
                    isGameOver = true
                    onGameOver(score)
                }
            }

            // 2. Right Paddle (AI) at X = 0.95f
            if (ballX + ballSize > 0.95f - paddleWidth / 2f) {
                // Check if Y overlaps AI Paddle
                if (ballY >= aiY - paddleHeight / 2f && ballY <= aiY + paddleHeight / 2f) {
                    ballX = 0.95f - paddleWidth / 2f - ballSize
                    ballVx = -ballVx
                } else if (ballX > 1.0f) {
                    // AI missed! Reset ball and score big
                    ballX = 0.5f
                    ballY = 0.5f
                    ballVx = -0.008f // Towards player
                    ballVy = (Random.nextFloat() * 0.01f - 0.005f)
                    score += 5 // Bonus for scoring on AI!
                }
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(16.dp))
            .border(2.dp, Color(0xFF00E5FF), RoundedCornerShape(16.dp))
            .background(Color(0xFF060D1E))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // --- Header (Scores) ---
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("SCORE", color = Color(0xFF80DEEA), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Text(String.format("%04d", score), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, fontFamily = FontFamily.Monospace)
            }
            Text("NEON PONG", color = Color(0xFF00E5FF), fontSize = 14.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace)
            Column(horizontalAlignment = Alignment.End) {
                Text("HI-SCORE", color = Color(0xFF80DEEA), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Text(String.format("%04d", highScore), color = Color(0xFFFFD700), fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, fontFamily = FontFamily.Monospace)
            }
        }

        // --- Game Field ---
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(vertical = 12.dp)
                .border(1.dp, Color(0x3F00E5FF), RoundedCornerShape(8.dp))
                .background(Color(0xFF03070E))
                .pointerInput(isPlaying) {
                    if (!isPlaying) return@pointerInput
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        val heightPx = size.height
                        val relativeMove = dragAmount.y / heightPx
                        playerY = (playerY + relativeMove).coerceIn(paddleHeight / 2f, 1.0f - paddleHeight / 2f)
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val width = size.width
                val height = size.height

                // Draw center divider dashed line
                val dashCount = 15
                val dashHeight = height / (dashCount * 2)
                for (i in 0 until dashCount) {
                    drawRect(
                        color = Color(0x2F00E5FF),
                        topLeft = Offset(width / 2f - 2f, i * 2f * dashHeight),
                        size = Size(4f, dashHeight)
                    )
                }

                // Draw Player Paddle (Left, X=0.05)
                drawRoundRect(
                    color = Color(0xFF00E5FF),
                    topLeft = Offset((0.05f - paddleWidth / 2f) * width, (playerY - paddleHeight / 2f) * height),
                    size = Size(paddleWidth * width, paddleHeight * height),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f, 6f)
                )

                // Draw AI Paddle (Right, X=0.95)
                drawRoundRect(
                    color = Color(0xFFFF007F),
                    topLeft = Offset((0.95f - paddleWidth / 2f) * width, (aiY - paddleHeight / 2f) * height),
                    size = Size(paddleWidth * width, paddleHeight * height),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f, 6f)
                )

                // Draw Ball
                drawCircle(
                    color = Color.White,
                    radius = ballSize * width,
                    center = Offset(ballX * width, ballY * height)
                )
            }

            // Overlay Screens
            if (!isPlaying && !isGameOver) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xEE03070E)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("NEON PONG READY", color = Color(0xFF00E5FF), fontSize = 20.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        Text("Drag left side of field to move", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp, bottom = 16.dp))
                        Button(
                            onClick = {
                                ballX = 0.5f
                                ballY = 0.5f
                                ballVx = 0.008f
                                ballVy = 0.004f
                                playerY = 0.5f
                                aiY = 0.5f
                                score = 0
                                isGameOver = false
                                isPlaying = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF), contentColor = Color.Black)
                        ) {
                            Text("START GAME")
                        }
                    }
                }
            } else if (isGameOver) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xEE03070E)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("GAME OVER", color = Color(0xFFFF007F), fontSize = 24.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        Text("Final Score: $score", color = Color.White, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = {
                                ballX = 0.5f
                                ballY = 0.5f
                                ballVx = 0.008f
                                ballVy = 0.004f
                                playerY = 0.5f
                                aiY = 0.5f
                                score = 0
                                isGameOver = false
                                isPlaying = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF), contentColor = Color.Black)
                        ) {
                            Text("PLAY AGAIN")
                        }
                    }
                }
            }
        }

        // Help tip
        Text(
            text = "Tip: Slide your finger up and down anywhere on the left to move your paddle",
            color = Color.White.copy(alpha = 0.4f),
            fontSize = 10.sp,
            modifier = Modifier.padding(top = 4.dp)
        )
    }
}
