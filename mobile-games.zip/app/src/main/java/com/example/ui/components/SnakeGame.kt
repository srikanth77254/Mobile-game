package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.random.Random

enum class Direction { UP, DOWN, LEFT, RIGHT }
data class SnakePart(val x: Int, val y: Int)

@Composable
fun SnakeGame(
    highScore: Int,
    onGameOver: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    // Grid Size
    val gridWidth = 20
    val gridHeight = 20

    // States
    var snake by remember { mutableStateOf(listOf(SnakePart(10, 10), SnakePart(10, 11), SnakePart(10, 12))) }
    var apple by remember { mutableStateOf(SnakePart(5, 5)) }
    var direction by remember { mutableStateOf(Direction.UP) }
    var score by remember { mutableStateOf(0) }
    var isPlaying by remember { mutableStateOf(false) }
    var isGameOver by remember { mutableStateOf(false) }

    // Speed of snake
    val delayMs = 150L

    // Loop
    LaunchedEffect(isPlaying) {
        if (!isPlaying) return@LaunchedEffect
        while (isPlaying) {
            delay(delayMs)

            // Calculate next head position
            val head = snake.first()
            val nextHead = when (direction) {
                Direction.UP -> SnakePart(head.x, head.y - 1)
                Direction.DOWN -> SnakePart(head.x, head.y + 1)
                Direction.LEFT -> SnakePart(head.x - 1, head.y)
                Direction.RIGHT -> SnakePart(head.x + 1, head.y)
            }

            // Boundary collision or self collision check
            val hitWall = nextHead.x < 0 || nextHead.x >= gridWidth || nextHead.y < 0 || nextHead.y >= gridHeight
            val hitSelf = snake.contains(nextHead)

            if (hitWall || hitSelf) {
                isPlaying = false
                isGameOver = true
                onGameOver(score)
            } else {
                val newSnake = mutableListOf(nextHead)
                
                // Eat apple check
                if (nextHead == apple) {
                    score += 10
                    newSnake.addAll(snake)
                    // Generate new apple
                    var newApple = SnakePart(Random.nextInt(gridWidth), Random.nextInt(gridHeight))
                    while (snake.contains(newApple)) {
                        newApple = SnakePart(Random.nextInt(gridWidth), Random.nextInt(gridHeight))
                    }
                    apple = newApple
                } else {
                    newSnake.addAll(snake.dropLast(1))
                }
                snake = newSnake
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(16.dp))
            .border(2.dp, Color(0xFF4CAF50), RoundedCornerShape(16.dp))
            .background(Color(0xFF0D1B0E))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // --- Header (Scores) ---
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("SCORE", color = Color(0xFFA5D6A7), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Text(String.format("%04d", score), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, fontFamily = FontFamily.Monospace)
            }
            Text("RETRO SNAKE", color = Color(0xFF4CAF50), fontSize = 14.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace)
            Column(horizontalAlignment = Alignment.End) {
                Text("HI-SCORE", color = Color(0xFFA5D6A7), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Text(String.format("%04d", highScore), color = Color(0xFFFFD700), fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, fontFamily = FontFamily.Monospace)
            }
        }

        // --- Grid Canvas ---
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(vertical = 12.dp)
                .border(1.dp, Color(0x3F4CAF50), RoundedCornerShape(8.dp))
                .background(Color(0xFF070F08)),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val cellWidth = size.width / gridWidth
                val cellHeight = size.height / gridHeight

                // Draw Apple
                val appleX = apple.x * cellWidth
                val appleY = apple.y * cellHeight
                drawRect(
                    color = Color(0xFFFF5252),
                    topLeft = Offset(appleX + 2f, appleY + 2f),
                    size = Size(cellWidth - 4f, cellHeight - 4f)
                )

                // Draw Snake
                snake.forEachIndexed { index, part ->
                    val color = if (index == 0) Color(0xFF81C784) else Color(0xFF4CAF50)
                    val px = part.x * cellWidth
                    val py = part.y * cellHeight
                    drawRect(
                        color = color,
                        topLeft = Offset(px + 1f, py + 1f),
                        size = Size(cellWidth - 2f, cellHeight - 2f)
                    )
                }
            }

            // Overlay game screens
            if (!isPlaying && !isGameOver) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xEE070F08)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("SNAKE READY", color = Color(0xFF4CAF50), fontSize = 20.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = {
                                snake = listOf(SnakePart(10, 10), SnakePart(10, 11), SnakePart(10, 12))
                                direction = Direction.UP
                                score = 0
                                isGameOver = false
                                isPlaying = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50), contentColor = Color.Black)
                        ) {
                            Text("START GAME")
                        }
                    }
                }
            } else if (isGameOver) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xEE070F08)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("GAME OVER", color = Color(0xFFFF5252), fontSize = 24.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        Text("Final Score: $score", color = Color.White, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = {
                                snake = listOf(SnakePart(10, 10), SnakePart(10, 11), SnakePart(10, 12))
                                direction = Direction.UP
                                score = 0
                                isGameOver = false
                                isPlaying = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50), contentColor = Color.Black)
                        ) {
                            Text("PLAY AGAIN")
                        }
                    }
                }
            }
        }

        // --- Controls (Virtual D-Pad) ---
        Box(
            modifier = Modifier
                .height(150.dp)
                .fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                // UP Button
                IconButton(
                    onClick = { if (direction != Direction.DOWN) direction = Direction.UP },
                    enabled = isPlaying,
                    modifier = Modifier
                        .size(48.dp)
                        .background(Color(0x1FA5D6A7), CircleShape)
                        .border(1.5.dp, Color(0xFF4CAF50), CircleShape)
                ) {
                    Icon(Icons.Filled.KeyboardArrowUp, contentDescription = "Up", tint = Color.White)
                }

                Row(
                    modifier = Modifier.padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(24.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // LEFT Button
                    IconButton(
                        onClick = { if (direction != Direction.RIGHT) direction = Direction.LEFT },
                        enabled = isPlaying,
                        modifier = Modifier
                            .size(48.dp)
                            .background(Color(0x1FA5D6A7), CircleShape)
                            .border(1.5.dp, Color(0xFF4CAF50), CircleShape)
                    ) {
                        Icon(Icons.Filled.KeyboardArrowLeft, contentDescription = "Left", tint = Color.White)
                    }

                    Spacer(modifier = Modifier.size(32.dp)) // Middle spacer

                    // RIGHT Button
                    IconButton(
                        onClick = { if (direction != Direction.LEFT) direction = Direction.RIGHT },
                        enabled = isPlaying,
                        modifier = Modifier
                            .size(48.dp)
                            .background(Color(0x1FA5D6A7), CircleShape)
                            .border(1.5.dp, Color(0xFF4CAF50), CircleShape)
                    ) {
                        Icon(Icons.Filled.KeyboardArrowRight, contentDescription = "Right", tint = Color.White)
                    }
                }

                // DOWN Button
                IconButton(
                    onClick = { if (direction != Direction.UP) direction = Direction.DOWN },
                    enabled = isPlaying,
                    modifier = Modifier
                        .size(48.dp)
                        .background(Color(0x1FA5D6A7), CircleShape)
                        .border(1.5.dp, Color(0xFF4CAF50), CircleShape)
                ) {
                    Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Down", tint = Color.White)
                }
            }
        }
    }
}
