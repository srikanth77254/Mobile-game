package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import java.util.*
import kotlin.math.hypot
import kotlin.random.Random

// Game Data Models using Relative Coordinates (0.0 to 1.0)
data class Obstacle(
    val id: String = UUID.randomUUID().toString(),
    var x: Float,
    var y: Float,
    val size: Float, // Relative size (0.02 to 0.06)
    val speed: Float, // Downward velocity
    val color: Color,
    val isItem: Boolean = false, // Gold stars to collect!
    val rotationSpeed: Float = Random.nextFloat() * 100f - 50f,
    var currentRotation: Float = 0f
)

data class Particle(
    var x: Float,
    var y: Float,
    val vx: Float,
    val vy: Float,
    val color: Color,
    var alpha: Float = 1.0f,
    var size: Float,
    var life: Float = 1.0f, // 1.0 down to 0.0
    val decay: Float = Random.nextFloat() * 0.04f + 0.02f
)

@Composable
fun SpaceGame(
    highScore: Int,
    onGameOver: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    // Game States
    var isPlaying by remember { mutableStateOf(false) }
    var isPaused by remember { mutableStateOf(false) }
    var score by remember { mutableStateOf(0) }
    var currentHighScore by remember { mutableStateOf(highScore) }
    var shipX by remember { mutableStateOf(0.5f) } // Center
    val shipY = 0.82f // Stationary Y near bottom
    val shipSize = 0.05f // Radius-like size bounding-box ratio

    val obstacles = remember { mutableStateListOf<Obstacle>() }
    val particles = remember { mutableStateListOf<Particle>() }

    // Control options
    var useDragControl by remember { mutableStateOf(true) }

    // Screen Shake effect
    var shakeIntensity by remember { mutableStateOf(0f) }
    val shakeOffset by animateOffsetAsState(
        targetValue = if (shakeIntensity > 0) {
            Offset(
                (Random.nextFloat() * 20f - 10f) * shakeIntensity,
                (Random.nextFloat() * 20f - 10f) * shakeIntensity
            )
        } else Offset.Zero,
        animationSpec = spring(dampingRatio = Spring.DampingRatioHighBouncy),
        label = "ShakeOffset"
    )

    // Sync external highScore
    LaunchedEffect(highScore) {
        if (highScore > currentHighScore) {
            currentHighScore = highScore
        }
    }

    // Main Game Loop
    LaunchedEffect(isPlaying, isPaused) {
        if (!isPlaying || isPaused) return@LaunchedEffect

        var frameCount = 0L
        while (isActive) {
            delay(16) // Approx 60 FPS

            frameCount++
            
            // Decelerate screen shake
            if (shakeIntensity > 0) {
                shakeIntensity = (shakeIntensity - 0.1f).coerceAtLeast(0f)
            }

            // Gradually scale difficulty (asteroid density and speed)
            val difficultyMultiplier = 1f + (score / 150f)
            val baseSpawnInterval = (50 / difficultyMultiplier).coerceAtLeast(15f).toInt()

            // Spawn obstacles
            if (frameCount % baseSpawnInterval == 0L) {
                val isStar = Random.nextFloat() < 0.15f // 15% chance to spawn glowing golden core
                val size = if (isStar) 0.035f else Random.nextFloat() * 0.035f + 0.025f
                val speed = (Random.nextFloat() * 0.006f + 0.005f) * difficultyMultiplier
                val color = if (isStar) {
                    Color(0xFFFFD700) // Golden
                } else {
                    // Random cosmic/asteroid rock color
                    when (Random.nextInt(3)) {
                        0 -> Color(0xFFFF5252) // Flaming red
                        1 -> Color(0xFF90A4AE) // Space grey rock
                        else -> Color(0xFFFF9100) // Orange plasma rock
                    }
                }
                obstacles.add(
                    Obstacle(
                        x = Random.nextFloat().coerceIn(0.05f, 0.95f),
                        y = -0.05f,
                        size = size,
                        speed = speed,
                        color = color,
                        isItem = isStar
                    )
                )
            }

            // Update Obstacles position & check collisions
            val obstaclesIterator = obstacles.iterator()
            while (obstaclesIterator.hasNext()) {
                val obs = obstaclesIterator.next()
                obs.y += obs.speed
                obs.currentRotation = (obs.currentRotation + obs.rotationSpeed * 0.03f) % 360f

                // Collision detection (using distance hypotenuse scaled to square box ratios)
                val distance = hypot(obs.x - shipX, obs.y - shipY)
                val collisionThreshold = obs.size + shipSize - 0.012f

                if (distance < collisionThreshold) {
                    // Collision occurred!
                    if (obs.isItem) {
                        // Collected gold star!
                        score += 25
                        shakeIntensity = 0.5f
                        // Spawn colorful particles for collection
                        repeat(15) {
                            particles.add(
                                Particle(
                                    x = obs.x,
                                    y = obs.y,
                                    vx = (Random.nextFloat() * 0.02f - 0.01f),
                                    vy = (Random.nextFloat() * 0.02f - 0.01f),
                                    color = Color(0xFFFFD700),
                                    size = Random.nextFloat() * 12f + 4f
                                )
                            )
                        }
                        obstaclesIterator.remove()
                    } else {
                        // Asteroid crash!
                        isPlaying = false
                        shakeIntensity = 2.0f
                        
                        // Spawn spectacular explosion particles
                        repeat(40) {
                            particles.add(
                                Particle(
                                    x = shipX,
                                    y = shipY,
                                    vx = (Random.nextFloat() * 0.03f - 0.015f),
                                    vy = (Random.nextFloat() * 0.03f - 0.015f),
                                    color = if (Random.nextBoolean()) Color(0xFF00E5FF) else Color(0xFFFF3D00),
                                    size = Random.nextFloat() * 18f + 6f
                                )
                            )
                        }
                        
                        onGameOver(score)
                        if (score > currentHighScore) {
                            currentHighScore = score
                        }
                        break
                    }
                } else if (obs.y > 1.05f) {
                    // Obstacle passed successfully!
                    if (!obs.isItem) {
                        score += 10
                    }
                    obstaclesIterator.remove()
                }
            }

            // Update explosion particles
            val particlesIterator = particles.iterator()
            while (particlesIterator.hasNext()) {
                val p = particlesIterator.next()
                p.x += p.vx
                p.y += p.vy
                p.life -= p.decay
                p.alpha = p.life.coerceIn(0f, 1f)
                if (p.life <= 0f) {
                    particlesIterator.remove()
                }
            }
        }
    }

    // Handle left/right button controls (when drag is disabled)
    var isPressingLeft by remember { mutableStateOf(false) }
    var isPressingRight by remember { mutableStateOf(false) }
    LaunchedEffect(isPressingLeft, isPressingRight, isPlaying, isPaused) {
        if (!isPlaying || isPaused || useDragControl) return@LaunchedEffect
        while (isActive) {
            if (isPressingLeft) {
                shipX = (shipX - 0.022f).coerceAtLeast(0.06f)
            }
            if (isPressingRight) {
                shipX = (shipX + 0.022f).coerceAtLeast(0.06f).coerceAtMost(0.94f)
            }
            delay(16)
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(16.dp))
            .border(2.dp, Color(0x3F00E5FF), RoundedCornerShape(16.dp))
            .background(Color(0xFF070B19))
    ) {
        // Starry Sky background inside the box
        StarrySky(speedFactor = if (isPlaying && !isPaused) 2.5f else 0.5f)

        // Actual interactive Canvas
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .offset(x = with(LocalDensity.current) { shakeOffset.x.toDp() }, y = with(LocalDensity.current) { shakeOffset.y.toDp() })
                .pointerInput(isPlaying, isPaused, useDragControl) {
                    if (!isPlaying || isPaused || !useDragControl) return@pointerInput
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        val widthPx = size.width
                        val relativeMove = dragAmount.x / widthPx
                        shipX = (shipX + relativeMove).coerceIn(0.06f, 0.94f)
                    }
                }
        ) {
            val width = size.width
            val height = size.height

            // 1. Draw Star / Obstacles
            obstacles.forEach { obs ->
                val px = obs.x * width
                val py = obs.y * height
                val radius = obs.size * width

                if (obs.isItem) {
                    // Draw glowing collectible Star
                    rotate(degrees = obs.currentRotation, pivot = Offset(px, py)) {
                        val path = Path().apply {
                            val doubleRadius = radius * 1.3f
                            moveTo(px, py - doubleRadius)
                            lineTo(px + doubleRadius * 0.35f, py - doubleRadius * 0.35f)
                            lineTo(px + doubleRadius, py - doubleRadius * 0.35f)
                            lineTo(px + doubleRadius * 0.45f, py + doubleRadius * 0.1f)
                            lineTo(px + doubleRadius * 0.65f, py + doubleRadius * 0.8f)
                            lineTo(px, py + doubleRadius * 0.4f)
                            lineTo(px - doubleRadius * 0.65f, py + doubleRadius * 0.8f)
                            lineTo(px - doubleRadius * 0.45f, py + doubleRadius * 0.1f)
                            lineTo(px - doubleRadius, py - doubleRadius * 0.35f)
                            lineTo(px - doubleRadius * 0.35f, py - doubleRadius * 0.35f)
                            close()
                        }
                        drawPath(
                            path = path,
                            color = Color(0xFFFFD700)
                        )
                        drawCircle(
                            color = Color.White.copy(alpha = 0.5f),
                            radius = radius * 0.4f,
                            center = Offset(px, py)
                        )
                    }
                } else {
                    // Draw jagged Asteroid rock
                    rotate(degrees = obs.currentRotation, pivot = Offset(px, py)) {
                        val path = Path()
                        val pointsCount = 7
                        for (i in 0 until pointsCount) {
                            val angle = i * (2 * Math.PI / pointsCount)
                            val jitter = 0.7f + 0.4f * (kotlin.math.sin(obs.currentRotation + i * 2f) * 0.5f + 0.5f)
                            val offsetR = radius * jitter
                            val ox = px + (offsetR * kotlin.math.cos(angle)).toFloat()
                            val oy = py + (offsetR * kotlin.math.sin(angle)).toFloat()
                            if (i == 0) path.moveTo(ox, oy) else path.lineTo(ox, oy)
                        }
                        path.close()

                        // Rock gradient fill
                        drawPath(
                            path = path,
                            brush = Brush.radialGradient(
                                colors = listOf(obs.color, obs.color.copy(alpha = 0.5f), Color.Black),
                                center = Offset(px, py),
                                radius = radius
                            )
                        )

                        // Glowing plasma trail
                        drawCircle(
                            color = obs.color.copy(alpha = 0.15f),
                            radius = radius * 1.5f,
                            center = Offset(px, py)
                        )
                    }
                }
            }

            // 2. Draw Ship (wedge-shaped jet fighter)
            if (isPlaying || particles.isNotEmpty()) {
                val sx = shipX * width
                val sy = shipY * height
                val sRadius = shipSize * width

                // Spaceship body path
                val shipPath = Path().apply {
                    moveTo(sx, sy - sRadius) // Tip
                    lineTo(sx + sRadius * 0.8f, sy + sRadius * 0.8f) // Right wing
                    lineTo(sx + sRadius * 0.3f, sy + sRadius * 0.4f) // Right tail indent
                    lineTo(sx - sRadius * 0.3f, sy + sRadius * 0.4f) // Left tail indent
                    lineTo(sx - sRadius * 0.8f, sy + sRadius * 0.8f) // Left wing
                    close()
                }

                // Draw booster fire!
                if (isPlaying && !isPaused) {
                    val fireHeight = sRadius * (0.6f + Random.nextFloat() * 0.4f)
                    val firePath = Path().apply {
                        moveTo(sx - sRadius * 0.25f, sy + sRadius * 0.5f)
                        lineTo(sx, sy + sRadius * 0.5f + fireHeight)
                        lineTo(sx + sRadius * 0.25f, sy + sRadius * 0.5f)
                        close()
                    }
                    drawPath(
                        path = firePath,
                        brush = Brush.verticalGradient(
                            colors = listOf(Color(0xFFFF007F), Color(0xFFFFD700).copy(alpha = 0.1f)),
                            startY = sy + sRadius * 0.5f,
                            endY = sy + sRadius * 0.5f + fireHeight
                        )
                    )
                }

                // Draw Ship with futuristic Neon border
                drawPath(
                    path = shipPath,
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0xFF00E5FF), Color(0xFF0D47A1)),
                        center = Offset(sx, sy),
                        radius = sRadius
                    )
                )

                // Neon wing tips
                drawCircle(
                    color = Color(0xFF00E5FF),
                    radius = sRadius * 0.15f,
                    center = Offset(sx - sRadius * 0.8f, sy + sRadius * 0.8f)
                )
                drawCircle(
                    color = Color(0xFF00E5FF),
                    radius = sRadius * 0.15f,
                    center = Offset(sx + sRadius * 0.8f, sy + sRadius * 0.8f)
                )
            }

            // 3. Draw explosion particles
            particles.forEach { p ->
                val px = p.x * width
                val py = p.y * height
                drawCircle(
                    color = p.color.copy(alpha = p.alpha),
                    radius = p.size * (p.life * 0.8f + 0.2f),
                    center = Offset(px, py)
                )
            }
        }

        // --- Heads-Up Display (HUD) ---
        // Top HUD Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Score Board
            Column(
                modifier = Modifier
                    .background(Color(0x7F0A0E1A), RoundedCornerShape(8.dp))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "SCORE",
                    color = Color(0xFFA0AEC0),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = String.format("%04d", score),
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Monospace
                )
            }

            // Title
            Text(
                text = "SPACE RUNNER",
                color = Color(0xFF00E5FF),
                fontSize = 14.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace
            )

            // High Score Board
            Column(
                modifier = Modifier
                    .background(Color(0x7F0A0E1A), RoundedCornerShape(8.dp))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalAlignment = Alignment.End
            ) {
                Text(
                    text = "HI-SCORE",
                    color = Color(0xFFA0AEC0),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = String.format("%04d", currentHighScore),
                    color = Color(0xFFFFD700),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        // Overlay Game States (Start Screen, Paused, Game Over)
        if (!isPlaying) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xCC070B19)),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(24.dp)
                ) {
                    Text(
                        text = "SPACE ESCAPE",
                        color = Color(0xFF00E5FF),
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "RUNNER",
                        color = Color(0xFFFF007F),
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(bottom = 24.dp)
                    )

                    Text(
                        text = "Dodge asteroids. Collect golden cores.",
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = 13.sp,
                        modifier = Modifier.padding(bottom = 32.dp)
                    )

                    // Control selector toggle
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(24.dp))
                            .background(Color(0x1F1E294A))
                            .border(1.dp, Color(0x3F00E5FF), RoundedCornerShape(24.dp))
                            .padding(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = { useDragControl = true },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (useDragControl) Color(0xFF00E5FF) else Color.Transparent,
                                contentColor = if (useDragControl) Color.Black else Color.White
                            ),
                            shape = RoundedCornerShape(18.dp),
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                            modifier = Modifier.height(36.dp)
                        ) {
                            Text("Drag Ship", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = { useDragControl = false },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (!useDragControl) Color(0xFFFF007F) else Color.Transparent,
                                contentColor = if (!useDragControl) Color.White else Color.White
                            ),
                            shape = RoundedCornerShape(18.dp),
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                            modifier = Modifier.height(36.dp)
                        ) {
                            Text("Buttons", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(32.dp))

                    Button(
                        onClick = {
                            obstacles.clear()
                            score = 0
                            shipX = 0.5f
                            isPlaying = true
                            isPaused = false
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF00E5FF),
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(32.dp),
                        modifier = Modifier
                            .width(200.dp)
                            .height(56.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.PlayArrow, contentDescription = "Start")
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("LAUNCH SHIP", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
                        }
                    }
                }
            }
        } else if (isPaused) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xAA070B19)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "GAME PAUSED",
                        color = Color.White,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(bottom = 24.dp)
                    )

                    Button(
                        onClick = { isPaused = false },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF), contentColor = Color.Black)
                    ) {
                        Text("RESUME GAME")
                    }
                }
            }
        }

        // Gameplay Button Controls overlaid at bottom (only visible when not using drag-control and is playing)
        if (isPlaying && !isPaused) {
            // Pause trigger at top right
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(top = 80.dp, end = 16.dp),
                contentAlignment = Alignment.TopEnd
            ) {
                IconButton(
                    onClick = { isPaused = true },
                    modifier = Modifier
                        .size(36.dp)
                        .background(Color(0x7F0A0E1A), RoundedCornerShape(18.dp))
                ) {
                    Icon(
                        Icons.Filled.Pause,
                        contentDescription = "Pause",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            if (!useDragControl) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(bottom = 24.dp, start = 24.dp, end = 24.dp),
                    contentAlignment = Alignment.BottomCenter
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Left Move Button
                        Button(
                            onClick = {},
                            modifier = Modifier
                                .size(72.dp)
                                .pointerInput(Unit) {
                                    detectDragGestures(
                                        onDragStart = { isPressingLeft = true },
                                        onDragEnd = { isPressingLeft = false },
                                        onDragCancel = { isPressingLeft = false },
                                        onDrag = { _, _ -> }
                                    )
                                },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0x3F00E5FF),
                                contentColor = Color.White
                            ),
                            border = BorderStroke(1.5.dp, Color(0xFF00E5FF)),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Text("<", fontSize = 28.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }

                        // Right Move Button
                        Button(
                            onClick = {},
                            modifier = Modifier
                                .size(72.dp)
                                .pointerInput(Unit) {
                                    detectDragGestures(
                                        onDragStart = { isPressingRight = true },
                                        onDragEnd = { isPressingRight = false },
                                        onDragCancel = { isPressingRight = false },
                                        onDrag = { _, _ -> }
                                    )
                                },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0x3F00E5FF),
                                contentColor = Color.White
                            ),
                            border = BorderStroke(1.5.dp, Color(0xFF00E5FF)),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Text(">", fontSize = 28.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }
    }
}
