package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import kotlin.random.Random

data class Star(
    val x: Float,
    val y: Float,
    val size: Float,
    val alpha: Float,
    val speed: Float,
    val color: Color
)

@Composable
fun StarrySky(
    modifier: Modifier = Modifier,
    speedFactor: Float = 1.0f
) {
    val infiniteTransition = rememberInfiniteTransition(label = "StarrySkyTransition")
    val time by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1000f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 30000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "StarrySkyTime"
    )

    // Remember coordinates of stars so they don't regenerate on recomposition
    val stars = remember {
        List(80) {
            val isBlue = Random.nextBoolean()
            val color = if (isBlue) {
                Color(0xFF00E5FF).copy(alpha = Random.nextFloat() * 0.5f + 0.3f)
            } else {
                Color.White.copy(alpha = Random.nextFloat() * 0.6f + 0.4f)
            }
            Star(
                x = Random.nextFloat(),
                y = Random.nextFloat(),
                size = Random.nextFloat() * 4f + 1f,
                alpha = Random.nextFloat() * 0.8f + 0.2f,
                speed = Random.nextFloat() * 0.05f + 0.01f,
                color = color
            )
        }
    }

    Canvas(modifier = modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height

        stars.forEach { star ->
            // Calculate dynamic position
            val currentY = (star.y + time * star.speed * speedFactor) % 1.0f
            val px = star.x * width
            val py = currentY * height

            // Draw star with twinkling alpha
            val twinkle = if (star.size > 2.5f) {
                (1f + kotlin.math.sin(time * 0.5f + star.x * 100f)) * 0.3f + 0.4f
            } else {
                1.0f
            }

            drawCircle(
                color = star.color.copy(alpha = (star.alpha * twinkle).coerceIn(0f, 1f)),
                radius = star.size,
                center = Offset(px, py)
            )
        }
    }
}
