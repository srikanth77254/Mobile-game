package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.ScoreEntry
import com.example.data.ScoreRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class WorkshopViewModel(private val repository: ScoreRepository) : ViewModel() {

    // Main App Navigation States: 0 = Games, 1 = Workshop Guide, 2 = Leaderboards
    private val _selectedTab = MutableStateFlow(0)
    val selectedTab: StateFlow<Int> = _selectedTab.asStateFlow()

    // Game Mode: "SPACE_ESCAPE", "SNAKE", "PONG"
    private val _activeGameMode = MutableStateFlow("SPACE_ESCAPE")
    val activeGameMode: StateFlow<String> = _activeGameMode.asStateFlow()

    // Observe high scores dynamically from Room
    val spaceEscapeScores: StateFlow<List<ScoreEntry>> = repository.getTopScores("SPACE_ESCAPE")
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val snakeScores: StateFlow<List<ScoreEntry>> = repository.getTopScores("SNAKE")
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val pongScores: StateFlow<List<ScoreEntry>> = repository.getTopScores("PONG")
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun selectTab(tabIndex: Int) {
        _selectedTab.value = tabIndex
    }

    fun selectGameMode(mode: String) {
        _activeGameMode.value = mode
    }

    fun saveScore(playerName: String, score: Int, gameMode: String) {
        viewModelScope.launch {
            repository.insertScore(
                ScoreEntry(
                    playerName = if (playerName.isBlank()) "Anonymous Pilot" else playerName,
                    score = score,
                    gameMode = gameMode
                )
            )
        }
    }

    fun clearAllScores(gameMode: String) {
        viewModelScope.launch {
            repository.clearScores(gameMode)
        }
    }

    // Factory to easily construct with Repository
    class Factory(private val repository: ScoreRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(WorkshopViewModel::class.java)) {
                return WorkshopViewModel(repository) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}
